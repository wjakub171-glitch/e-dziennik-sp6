create extension if not exists pgcrypto;

create type public.user_role as enum ('director','vice_director','admin','teacher','student','parent');
create type public.attendance_status as enum ('present','absent','late','excused');
create type public.note_kind as enum ('note','praise');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 role public.user_role not null default 'student',
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.classes (
 id uuid primary key default gen_random_uuid(),
 name text not null unique,
 school_year text not null,
 created_at timestamptz not null default now()
);
create table public.students (
 id uuid primary key default gen_random_uuid(),
 profile_id uuid unique references public.profiles(id) on delete set null,
 class_id uuid references public.classes(id) on delete set null,
 register_number integer,
 created_at timestamptz not null default now(),
 unique(class_id,register_number)
);
create table public.parent_students (
 parent_id uuid not null references public.profiles(id) on delete cascade,
 student_id uuid not null references public.students(id) on delete cascade,
 primary key(parent_id,student_id)
);
create table public.subjects (
 id uuid primary key default gen_random_uuid(),
 name text not null unique
);
create table public.teacher_subjects (
 teacher_id uuid not null references public.profiles(id) on delete cascade,
 class_id uuid not null references public.classes(id) on delete cascade,
 subject_id uuid not null references public.subjects(id) on delete cascade,
 primary key(teacher_id,class_id,subject_id)
);
create table public.lessons (
 id uuid primary key default gen_random_uuid(),
 class_id uuid not null references public.classes(id) on delete cascade,
 subject_id uuid not null references public.subjects(id),
 teacher_id uuid not null references public.profiles(id),
 lesson_date date not null default current_date,
 lesson_number integer,
 topic text not null,
 plan text not null default '',
 created_at timestamptz not null default now()
);
create table public.grades (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.students(id) on delete cascade,
 subject_id uuid not null references public.subjects(id),
 value numeric(3,2) not null check(value >= 1 and value <= 6),
 category text not null default '',
 comment text not null default '',
 created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now()
);
create table public.attendance (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.students(id) on delete cascade,
 lesson_id uuid not null references public.lessons(id) on delete cascade,
 status public.attendance_status not null,
 marked_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 unique(student_id,lesson_id)
);
create table public.student_notes (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.students(id) on delete cascade,
 kind public.note_kind not null,
 content text not null,
 created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now()
);
create table public.messages (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.profiles(id),
 recipient_id uuid not null references public.profiles(id),
 subject text not null,
 body text not null,
 read_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.teacher_attendance (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid not null references public.profiles(id) on delete cascade,
 attendance_date date not null default current_date,
 status text not null check(status in ('present','absent','late','leave')),
 recorded_by uuid not null references public.profiles(id),
 unique(teacher_id,attendance_date)
);
create table public.number_draws (
 id uuid primary key default gen_random_uuid(),
 class_id uuid references public.classes(id) on delete set null,
 drawn_number integer not null,
 drawn_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now()
);
create table public.report_cards (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.students(id) on delete cascade,
 school_year text not null,
 average numeric(4,2),
 conduct text,
 honors_stripe boolean not null default false,
 generated_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 unique(student_id,school_year)
);

create or replace function public.current_role()
returns public.user_role language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() and active=true $$;

create or replace function public.is_management()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role() in ('director','vice_director','admin'),false) $$;

create or replace function public.can_see_student(target_student uuid)
returns boolean language sql stable security definer set search_path=public
as $$
 select public.is_management()
 or exists(select 1 from public.students s where s.id=target_student and s.profile_id=auth.uid())
 or exists(select 1 from public.parent_students ps where ps.student_id=target_student and ps.parent_id=auth.uid())
 or (public.current_role()='teacher' and exists(
   select 1 from public.students s join public.teacher_subjects ts on ts.class_id=s.class_id
   where s.id=target_student and ts.teacher_id=auth.uid()
 ))
$$;

create or replace function public.can_teach_lesson(target_lesson uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select public.is_management() or exists(select 1 from public.lessons l where l.id=target_lesson and l.teacher_id=auth.uid()) $$;

alter table public.profiles enable row level security;
alter table public.classes enable row level security;
alter table public.students enable row level security;
alter table public.parent_students enable row level security;
alter table public.subjects enable row level security;
alter table public.teacher_subjects enable row level security;
alter table public.lessons enable row level security;
alter table public.grades enable row level security;
alter table public.attendance enable row level security;
alter table public.student_notes enable row level security;
alter table public.messages enable row level security;
alter table public.teacher_attendance enable row level security;
alter table public.number_draws enable row level security;
alter table public.report_cards enable row level security;

create policy "profiles self or management" on public.profiles for select using(id=auth.uid() or public.is_management());
create policy "management updates profiles" on public.profiles for update using(public.is_management()) with check(public.is_management());
create policy "management inserts profiles" on public.profiles for insert with check(public.is_management());

create policy "classes visible to signed in" on public.classes for select to authenticated using(true);
create policy "management manages classes" on public.classes for all using(public.is_management()) with check(public.is_management());
create policy "student can see self row" on public.students for select using(public.can_see_student(id));
create policy "management manages students" on public.students for all using(public.is_management()) with check(public.is_management());
create policy "parent sees own relationships" on public.parent_students for select using(parent_id=auth.uid() or public.is_management());
create policy "management manages parent links" on public.parent_students for all using(public.is_management()) with check(public.is_management());
create policy "subjects signed in read" on public.subjects for select to authenticated using(true);
create policy "management manages subjects" on public.subjects for all using(public.is_management()) with check(public.is_management());
create policy "teacher assignments readable" on public.teacher_subjects for select using(teacher_id=auth.uid() or public.is_management());
create policy "management manages assignments" on public.teacher_subjects for all using(public.is_management()) with check(public.is_management());
create policy "lessons visible by class relationship" on public.lessons for select using(
 public.is_management() or teacher_id=auth.uid() or exists(select 1 from public.students s where s.class_id=lessons.class_id and public.can_see_student(s.id))
);
create policy "authorized staff creates lessons" on public.lessons for insert with check(public.is_management() or (public.current_role()='teacher' and teacher_id=auth.uid() and exists(select 1 from public.teacher_subjects ts where ts.teacher_id=auth.uid() and ts.class_id=lessons.class_id and ts.subject_id=lessons.subject_id)));
create policy "lesson teacher or management updates" on public.lessons for update using(public.is_management() or teacher_id=auth.uid()) with check(public.is_management() or teacher_id=auth.uid());

create policy "grades readable by linked people" on public.grades for select using(public.can_see_student(student_id));
create policy "staff inserts grades" on public.grades for insert with check(
 public.is_management() or (public.current_role()='teacher' and created_by=auth.uid() and exists(
 select 1 from public.students s join public.teacher_subjects ts on ts.class_id=s.class_id and ts.subject_id=grades.subject_id where s.id=grades.student_id and ts.teacher_id=auth.uid()
 )));
create policy "staff updates grades" on public.grades for update using(public.is_management() or (public.current_role()='teacher' and exists(select 1 from public.students s join public.teacher_subjects ts on ts.class_id=s.class_id and ts.subject_id=grades.subject_id where s.id=grades.student_id and ts.teacher_id=auth.uid()))) with check(public.is_management() or public.current_role()='teacher');
create policy "management deletes grades" on public.grades for delete using(public.is_management());

create policy "attendance readable by linked people" on public.attendance for select using(public.can_see_student(student_id));
create policy "staff marks attendance for own lessons" on public.attendance for insert with check(public.is_management() or (public.current_role()='teacher' and marked_by=auth.uid() and public.can_teach_lesson(lesson_id) and exists(select 1 from public.lessons l join public.students s on s.class_id=l.class_id where l.id=attendance.lesson_id and s.id=attendance.student_id)));
create policy "staff updates attendance" on public.attendance for update using(public.is_management() or (public.current_role()='teacher' and public.can_teach_lesson(lesson_id))) with check(public.is_management() or public.current_role()='teacher');
create policy "management deletes attendance" on public.attendance for delete using(public.is_management());

create policy "notes readable by linked people" on public.student_notes for select using(public.can_see_student(student_id));
create policy "staff creates notes" on public.student_notes for insert with check(public.is_management() or (public.current_role()='teacher' and created_by=auth.uid() and public.can_see_student(student_id)));
create policy "management manages notes" on public.student_notes for all using(public.is_management()) with check(public.is_management());

create policy "messages sender or recipient" on public.messages for select using(sender_id=auth.uid() or recipient_id=auth.uid() or public.is_management());
create policy "send own messages" on public.messages for insert with check(sender_id=auth.uid() and recipient_id<>auth.uid());
create policy "recipient marks message read" on public.messages for update using(recipient_id=auth.uid()) with check(recipient_id=auth.uid());

create policy "teacher attendance visible to management and self" on public.teacher_attendance for select using(teacher_id=auth.uid() or public.is_management());
create policy "management records teacher attendance" on public.teacher_attendance for all using(public.is_management()) with check(public.is_management());
create policy "number draws visible to signed-in" on public.number_draws for select to authenticated using(true);
create policy "management draws numbers" on public.number_draws for insert with check(public.is_management() and drawn_by=auth.uid());
create policy "report cards visible by student relationship" on public.report_cards for select using(public.can_see_student(student_id));
create policy "management manages report cards" on public.report_cards for all using(public.is_management()) with check(public.is_management());

-- Role assignment should be done by trusted school management outside self-service signup.
-- Do not expose service_role keys in browser code.
