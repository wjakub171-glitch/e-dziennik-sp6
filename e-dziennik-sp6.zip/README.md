# e-Dziennik Szkoły Podstawowej nr 6

Starter aplikacji: Next.js (App Router) + TypeScript + Supabase (PostgreSQL, Auth, Row Level Security).

## Co zawiera
- logowanie przez Supabase Auth;
- role: `director`, `vice_director`, `admin`, `teacher`, `student`, `parent`;
- przykładowy panel z nawigacją zależną od roli;
- schemat bazy dla klas, relacji rodzic–uczeń, ocen, frekwencji, lekcji, uwag, pochwał, wiadomości, losowania numerków i świadectw;
- polityki RLS jako dodatkowa warstwa ochrony danych;
- serwerowe API do zapisu ocen, frekwencji, uwag/pochwał i wiadomości;
- strona wydruku świadectwa.

## Uruchomienie
1. Zainstaluj Node.js 20+.
2. W terminalu w folderze projektu:
   ```bash
   npm install
   cp .env.example .env.local
   ```
3. Utwórz projekt w Supabase i uzupełnij `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (tylko po stronie serwera; nigdy nie dodawaj do `NEXT_PUBLIC_*`)
4. W Supabase SQL Editor uruchom `supabase/migrations/001_initial.sql`.
5. W Supabase Authentication ustaw adres URL aplikacji i dozwolone adresy przekierowań.
6. Utwórz pierwsze konto w Supabase Auth. Następnie, jako właściciel bazy, przypisz mu rolę w tabeli `profiles` (przykład poniżej).
7. Uruchom `npm run dev` i otwórz `http://localhost:3000`.

Przykład przypisania roli (zastąp UUID prawdziwym `auth.users.id`):
```sql
insert into public.profiles (id, full_name, role)
values ('UUID-KONTA-Z-SUPABASE', 'Dyrektor', 'director')
on conflict (id) do update set role = excluded.role;
```

## Ważne przed prawdziwym wdrożeniem
To jest działający szkielet do skonfigurowania, a nie gotowy, certyfikowany system szkolny. Nie wpisuj prawdziwych danych uczniów przed testami i audytem bezpieczeństwa. Włącz MFA dla kadry, kopie zapasowe, limity logowania, monitoring i procedurę odzyskiwania kont. Klucza `SUPABASE_SERVICE_ROLE_KEY` nie wolno wysyłać do przeglądarki. Przed użyciem w szkole sprawdź zgodność z RODO, retencję danych, podstawy prawne, procedury świadectw i zasady dostępu. Wydruki są roboczym szablonem, nie urzędowym wzorem świadectwa.
