export const roleLabels = {
  director:"Dyrektor", vice_director:"Wicedyrektor", admin:"Administrator",
  teacher:"Nauczyciel", student:"Uczeń", parent:"Rodzic"
} as const;
export type Role = keyof typeof roleLabels;
export const managementRoles: Role[] = ["director","vice_director","admin"];
export const teachingRoles: Role[] = ["director","vice_director","admin","teacher"];
export function canManage(role: Role){return managementRoles.includes(role);}
