import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
export async function createClient() {
  const jar = cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: { get(name:string){return jar.get(name)?.value;}, set(name:string,value:string,options:any){try{jar.set({name,value,...options});}catch{}}, remove(name:string,options:any){try{jar.set({name,value:"",...options});}catch{}} }
  });
}
