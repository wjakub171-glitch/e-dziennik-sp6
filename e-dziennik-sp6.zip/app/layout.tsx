import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "e-Dziennik Szkoły Podstawowej nr 6", description: "Elektroniczny dziennik szkolny" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="pl"><body>{children}</body></html>; }
