import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
import {canManage,type Role} from "@/lib/roles";
export async function POST(req:Request){
 const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)return NextResponse.json({error:"Brak logowania"}, {status:401});
 const {data:p}=await db.from("profiles").select("role").eq("id",user.id).single();if(!p||!["director","vice_director","admin","teacher"].includes(p.role))return NextResponse.json({error:"Brak uprawnień"}, {status:403});
 const body=await req.json();if(!body.student_id||!body.subject_id||!Number.isFinite(Number(body.value))||Number(body.value)<1||Number(body.value)>6)return NextResponse.json({error:"Nieprawidłowe dane oceny"}, {status:400});
 const {data,error}=await db.from("grades").insert({student_id:body.student_id,subject_id:body.subject_id,value:Number(body.value),category:String(body.category||"").slice(0,100),comment:String(body.comment||"").slice(0,1000),created_by:user.id}).select().single();
 if(error)return NextResponse.json({error:"Nie udało się zapisać oceny"}, {status:400});return NextResponse.json({data});
}
