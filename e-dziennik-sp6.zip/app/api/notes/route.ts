import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
export async function POST(req:Request){
 const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)return NextResponse.json({error:"Brak logowania"},{status:401});
 const {data:p}=await db.from("profiles").select("role").eq("id",user.id).single();if(!p||!["director","vice_director","admin","teacher"].includes(p.role))return NextResponse.json({error:"Brak uprawnień"},{status:403});
 const b=await req.json();if(!b.student_id||!["note","praise"].includes(b.kind)||typeof b.content!=="string"||!b.content.trim())return NextResponse.json({error:"Nieprawidłowe dane"},{status:400});
 const {data,error}=await db.from("student_notes").insert({student_id:b.student_id,kind:b.kind,content:b.content.trim().slice(0,2000),created_by:user.id}).select().single();
 if(error)return NextResponse.json({error:"Nie udało się zapisać wpisu"},{status:400});return NextResponse.json({data});
}
