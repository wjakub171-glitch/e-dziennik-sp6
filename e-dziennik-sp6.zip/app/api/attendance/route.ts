import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
export async function POST(req:Request){
 const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)return NextResponse.json({error:"Brak logowania"},{status:401});
 const {data:p}=await db.from("profiles").select("role").eq("id",user.id).single();if(!p||!["director","vice_director","admin","teacher"].includes(p.role))return NextResponse.json({error:"Brak uprawnień"},{status:403});
 const b=await req.json();const allowed=["present","absent","late","excused"];if(!b.student_id||!b.lesson_id||!allowed.includes(b.status))return NextResponse.json({error:"Nieprawidłowe dane"},{status:400});
 const {data,error}=await db.from("attendance").upsert({student_id:b.student_id,lesson_id:b.lesson_id,status:b.status,marked_by:user.id},{onConflict:"student_id,lesson_id"}).select().single();
 if(error)return NextResponse.json({error:"Nie udało się zapisać frekwencji"},{status:400});return NextResponse.json({data});
}
