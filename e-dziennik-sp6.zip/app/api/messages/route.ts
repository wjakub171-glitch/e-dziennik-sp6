import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
export async function POST(req:Request){
 const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)return NextResponse.json({error:"Brak logowania"},{status:401});
 const b=await req.json();if(typeof b.recipient_id!=="string"||typeof b.subject!=="string"||typeof b.body!=="string"||!b.subject.trim()||!b.body.trim())return NextResponse.json({error:"Nieprawidłowe dane"},{status:400});
 const {data,error}=await db.from("messages").insert({sender_id:user.id,recipient_id:b.recipient_id,subject:b.subject.trim().slice(0,180),body:b.body.trim().slice(0,10000)}).select().single();
 if(error)return NextResponse.json({error:"Nie udało się wysłać wiadomości"}, {status:400});return NextResponse.json({data});
}
